import os
import dash
import numpy as np
import json
import dash_bootstrap_components as dbc
import dash_mantine_components as dmc
from dash import Dash, dcc, html, no_update
from icecream import install, ic
import pythermalcomfort as pm
from components.footer import my_footer
from components.navbar import my_navbar
from utils.my_config_file import (
    Config,
    Stores,
    ElementsIDs,
    Dimensions,
    AdaptiveEN,
    ModelInputsAdaptiveEN16798
)
from utils.website_text import app_name
from dash.dependencies import Input, Output, State
from components.dropdowns import (
    dd_model,
    ashare_chart,
    pmv_en_chart,
)
from components.input_environmental_personal import input_environmental_personal
from components.dropdowns import chart_selection,adaptive_en_air_speed, adaptive_ashare_air_speed
from components.charts import chart_example
from utils.my_config_file import (
    MODELS,
    AdaptiveEN,
    AdaptiveAshrae,
    PmvAshraeResultCard,
    PmvENResultCard,
    PhsResultCard,
)

install()
# from components.dropdowns import Ash55_air_speed_selection
ic.configureOutput(includeContext=True)

# try:
#     cred = credentials.Certificate("secret.json")
# except FileNotFoundError:
#     cred = credentials.Certificate(json.loads(os.environ.get("firebase_secret")))
#
# firebase_admin.initialize_app(
#     cred,
#     {"databaseURL": FirebaseFields.database_url},
# )

# This is required by dash mantine components to work with react 18
dash._dash_renderer._set_react_version("18.2.0")


# Exposing the Flask Server to enable configuring it for logging in
app = Dash(
    __name__,
    title=app_name,
    update_title="Loading...",
    external_stylesheets=[
        dbc.themes.BOOTSTRAP,
        "https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css",
        # include google fonts
        "https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;900&display=swap",
        # dash mantine stylesheets
        "https://unpkg.com/@mantine/dates@7/styles.css",
        "https://unpkg.com/@mantine/code-highlight@7/styles.css",
        "https://unpkg.com/@mantine/charts@7/styles.css",
        "https://unpkg.com/@mantine/carousel@7/styles.css",
        "https://unpkg.com/@mantine/notifications@7/styles.css",
        "https://unpkg.com/@mantine/nprogress@7/styles.css",
    ],
    external_scripts=["https://cdn.plot.ly/plotly-basic-2.26.2.min.js"],
    prevent_initial_callbacks=True,
    use_pages=True,
    serve_locally=False,
)
app.config.suppress_callback_exceptions = True

# app.index_string = """<!DOCTYPE html>
# <html lang="en-AU">
# <head>
#     <!-- Google tag (gtag.js) -->
#     <script async src="https://www.googletagmanager.com/gtag/js?id=G-MZFW54YKZ5"></script>
#     <script>
#       window.dataLayer = window.dataLayer || [];
#       function gtag(){dataLayer.push(arguments);}
#       gtag('js', new Date());
#
#       gtag('config', 'G-MZFW54YKZ5');
#     </script>
#     <meta charset="utf-8">
#     <link rel="apple-touch-icon" href="/assets/media/CBE-logo-2018.png"/>
#     <link rel="apple-touch-icon" sizes="180x180" href="/assets/media/CBE-logo-2018.png">
#     <link rel="icon" type="image/png" sizes="32x32" href="/assets/media/CBE-logo-2018.png">
#     <link rel="icon" type="image/png" sizes="16x16" href="/assets/media/CBE-logo-2018.png">
#     <link rel="manifest" href="./assets/manifest.json">
#     <meta name="viewport" content="width=device-width, initial-scale=1.0">
#     <meta name="author" content="Federico Tartarini">
#     <meta name="keywords" content="">
#     <meta name="description" content="">
#     <meta name="theme-color" content="#E64626" />
#     <title>HeatWatch</title>
#     <meta property="og:image" content="./assets/media/CBE-logo-2018.png">
#     <meta property="og:description" content="">
#     <meta property="og:title" content="">
#     {%favicon%}
#     {%css%}
# </head>
# <body>
# <script>
#   if ('serviceWorker' in navigator) {
#     window.addEventListener('load', ()=> {
#       navigator
#       .serviceWorker
#       .register("./assets/sw01.js")
#       .then(()=>console.log("Ready."))
#       .catch((e)=>console.log("Err...", e));
#     });
#   }
# </script>
# {%app_entry%}
# <footer>
# {%config%}
# {%scripts%}
# {%renderer%}
# </footer>
# </body>
# </html>
# """
def output_box():
    return html.Div(
        id='output',
        style={
            'border': '1px solid black',
            'padding': '10px',
            'margin-top': '20px'
        }
    )
def output_box2():
    return html.Div(
        id='output2',
        style={
            'border': '1px solid black',
            'padding': '10px',
            'margin-top': '20px'
        }
    )
def output_box3():
    return html.Div(
        id='output3',
        style={
            'border': '1px solid black',
            'padding': '10px',
            'margin-top': '20px'
        }
    )
def output_box4():
    return html.Div(
        id='output4',
        style={
            'border': '1px solid black',
            'padding': '10px',
            'margin-top': '20px'
        }
    )
app.layout = dmc.MantineProvider(
    defaultColorScheme="light",
    theme={
        "colorScheme": "dark",
        "fontFamily": "'Inter', sans-serif",
        "primaryColor": "indigo",
        "components": {
            "Button": {"styles": {"root": {"fontWeight": 400}}},
            "Alert": {"styles": {"title": {"fontWeight": 500}}},
            "AvatarGroup": {"styles": {"truncated": {"fontWeight": 500}}},
        },
    },
    children=html.Div(
        [
            my_navbar(),
            dcc.Location(id=ElementsIDs.URL.value),
            dcc.Store(id=Stores.INPUT_DATA.value, storage_type="local"),
            html.Div(
                dmc.Container(
                    dash.page_container,
                    p="xs",
                    size=Dimensions.default_container_width.value,
                ),
                style={
                    "paddingBottom": "6.5rem",
                },
            ),
            my_footer(),
            output_box(),
            output_box2(),
            output_box3(),
            output_box4()
        ],
        style={
            "minHeight": "100vh",
            "position": "relative",
        },
    ),
)


# @app.server.route("/sitemap/")
# def sitemap():
#     return Response(
#         """<?xml version="1.0" encoding="UTF-8"?>
#         <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
#           <url>
#             <loc>https://heatwatch.sydney.sydney.edu.au</loc>
#             <lastmod>2023-10-05T04:22:26+00:00</lastmod>
#           </url>
#           <url>
#             <loc>https://heatwatch.sydney.edu.au/settings</loc>
#             <lastmod>2023-10-05T04:22:26+00:00</lastmod>
#           </url>
#         </urlset>
#         """,
#         mimetype="text/xml",
#     )


# @app.callback(
#     Output(ElementsIDs.CHART_CONTAINER.value,"figure"),
#     Input(ashare_chart["id"],"value"),
#     State(dd_model["id"], "value"),
# )
# def update_chart_content(select_chart,selected_model):
#     print("callbacks (select chart): ", selected_model, select_chart)
#     figure_content = chart_example(selected_model,select_chart)

#     return figure_content


@app.callback(
    Output("input_card", "children"),
    Output("graph-container", "children"),
    Output("chart-select", "children"),
    Output("graph-container", "cols"),
    Output(ElementsIDs.CHART_CONTAINER.value, "figure"),
    Input(dd_model["id"], "value"),
    Input(ashare_chart["id"], "value"),
)
def capture_selected_model(selected_model, selected_chart):
    # print("callbacks (select model) enable")

    if not selected_model:
        no_update, no_update, no_update, no_update, no_update

    input_content = input_environmental_personal(selected_model)
    graph_content = update_graph_content(selected_model)
    chart_content = chart_selection(selected_model, selected_chart)
    result_content = change_cols(selected_model)

    if (
        selected_model == MODELS.Phs.value
        or selected_model == MODELS.Adaptive_ashrae.value
        or selected_model == MODELS.Adaptive_EN.value
        or selected_model == MODELS.Fans_heat.value
    ):
        # print(selected_model, select_chart)
        figure_content = chart_example(selected_model, None)
    else:
        # print(selected_model, select_chart)
        figure_content = chart_example(selected_model, selected_chart)

    return input_content, graph_content, chart_content, result_content, figure_content


def change_cols(selected_model):
    if (
        selected_model == MODELS.Adaptive_EN.value
        or selected_model == MODELS.Adaptive_ashrae.value
        or selected_model == MODELS.Phs.value
    ):
        cols = 1
    else:
        cols = 3
    return cols


def update_graph_content(selected_model):

    if selected_model == MODELS.Adaptive_EN.value:
        grid_content = [
            dmc.Center(dmc.Text(AdaptiveEN.class_III.value)),
            dmc.Center(dmc.Text(AdaptiveEN.class_II.value)),
            dmc.Center(dmc.Text(AdaptiveEN.class_I.value)),
            dmc.Center(dmc.Text(AdaptiveEN.adaptive_chart.value)),
        ]
    elif selected_model == MODELS.Adaptive_ashrae.value:
        grid_content = [
            dmc.Center(dmc.Text(AdaptiveAshrae.acceptability_limits_80.value)),
            dmc.Center(dmc.Text(AdaptiveAshrae.acceptability_limits_90.value)),
            dmc.Center(dmc.Text(AdaptiveAshrae.adaptive_chart.value)),
        ]
    elif selected_model == MODELS.PMV_ashrae.value:
        grid_content = [
            dmc.Center(dmc.Text(PmvAshraeResultCard.pmv.value)),
            dmc.Center(dmc.Text(PmvAshraeResultCard.ppd.value)),
            dmc.Center(dmc.Text(PmvAshraeResultCard.sensation.value)),
            dmc.Center(dmc.Text(PmvAshraeResultCard.set.value)),
        ]
    elif selected_model == MODELS.PMV_EN.value:
        grid_content = [
            dmc.Center(dmc.Text(PmvENResultCard.pmv.value)),
            dmc.Center(dmc.Text(PmvENResultCard.ppd.value)),
            dmc.Center(dmc.Text(PmvENResultCard.set.value)),
        ]

    elif selected_model == MODELS.Fans_heat.value:
        grid_content = []

    elif selected_model == MODELS.Phs.value:
        print(f"Received Input States: {input_states}")

        if any(x is None or (isinstance(x, float) and isnan(x)) for x in input_states):
            print("Invalid input values detected, skipping calculation.")
            return [dmc.Text("Invalid inputs, unable to calculate PHS.")], 1

        try:
            t_re, d_lim_loss_50, d_lim_loss_95 = CalculatePHS(*input_states)
            print(f"Calculation Results - t_re: {t_re}, d_lim_loss_50: {d_lim_loss_50}, d_lim_loss_95: {d_lim_loss_95}")

            grid_content = [
                dmc.Center(dmc.Text(PhsResultCard.line1.value)),
                dmc.Center(dmc.Text(PhsResultCard.line2.value.replace("t_re", f"{t_re:.1f}"))),
                dmc.Center(dmc.Text(PhsResultCard.line3.value.replace("d_lim_loss_95", f"{d_lim_loss_95:.1f}"))),
                dmc.Center(dmc.Text(PhsResultCard.line4.value.replace("d_lim_loss_50", f"{d_lim_loss_50:.1f}"))),
            ]
        except Exception as e:
            print(f"Error during calculation: {e}")
            grid_content = [dmc.Text("Error in calculating PHS.")]

    else:
        grid_content = []

    return grid_content


@app.callback(
    Output('output', 'children'),
    [
        Input(adaptive_en_air_speed["id"], 'value'),
        Input('AIR_TEMPERATURE', 'value'),
        Input('MRT', 'value'),
        Input('RUNNING_MEAN_OUTDOOR_TEMPERATURE', 'value')
    ]
)
def adaptive_en_calculation(speed,air_temp,mrt,running_meam_temp):

    if speed == "0.6 m/s (118fpm)":
        correction = 0.6
    elif speed == "0.9 m/s (177fpm)":
        correction = 0.9
    elif speed == "1.2 m/s (236fpm)":
        correction = 1.2
    else:
        correction = 0.3  #原始项目speed 中lower than 0.6 不是确切数值，所以设了0.3
    res = pm.adaptive_en(air_temp,mrt,running_meam_temp,correction)
    for key, value in res.items():
        if isinstance(value, np.ndarray):
            res[key] = value.tolist()


    res_str = json.dumps(res, indent=2, ensure_ascii=False)
    print(res_str)
    return html.Pre(res_str)

@app.callback(  Output('output2', 'children'),
    [
        Input('TEMPERATURE', 'value'),
        # Input('TR','value'), #打勾兰，如果打上勾TR会有 Mean radiant temperature 的结果 但是目前前端未更新 所以我们直接设定值
        Input('AIR_SPEED', 'value'),
        Input('RH', 'value'),
        Input('MET','value'),
        Input('CLOTHING','value')

    ])
def pmv_ash_calculation(tem,air_speed,rh,met,clothing):
    tr=tem
    res = pm.pmv_ppd(tem,tr,air_speed,rh,met,clothing)
    for key, value in res.items():
        if isinstance(value, np.ndarray):
            res[key] = value.tolist()
    res_str = json.dumps(res, indent=2, ensure_ascii=False)
    print(res_str)
    return html.Pre(res_str)

@app.callback(  Output('output3', 'children'),
    [
        Input('AIR_TEMPERATURE', 'value'),
        Input('MRT','value'),
        Input('AIR_SPEED', 'value'),
        Input('RH', 'value'),
        Input('MET','value'),
        Input('DYNAMIC_CLOTHING','value')

    ])
def pmv_en_calculation(tem,mrt,v,rh,met,clo):
    relativeAirSpeed =0
    mrt=20#..  #在原始项目中这个应该是这个值
    if met > 1:
        relativeAirSpeed= v + 0.3 * (met - 1)
    else:
        relativeAirSpeed=v


    res = pm.pmv_ppd(tem,mrt,relativeAirSpeed,rh,met, clo)
    for key, value in res.items():
        if isinstance(value, np.ndarray):
            res[key] = value.tolist()

    res_str = json.dumps(res, indent=2, ensure_ascii=False)
    print(res_str)
    return html.Pre(res_str)

#FAN HEAT的需要向前端发送的参数请求太多，但是前端未完工所以这里没做好


#前端没有定义 comfort-data1
@app.callback(
    Output('output4', 'children'),
    [
        Input('AIR_TEMPERATURE', 'value'),
        Input('MRT', 'value'),
        Input(adaptive_ashare_air_speed["id"], 'value'),
    ]
)
def adaptive_ashrae_calculation(temp, mrt, speed):
    if speed == "0.6 m/s (118fpm)":
        correction = 0.6
    elif speed == "0.9 m/s (177fpm)":
        correction = 0.9
    elif speed == "1.2 m/s (236fpm)":
        correction = 1.2
    else:
        correction = 0.3
    # if selected_model == 'Adaptive - ASHRAE 55':
    # tmp_cmf, tmp_cmf_80_low, tmp_cmf_80_up, tmp_cmf_90_low, tmp_cmf_90_up, acceptability_80, acceptability_90 = Calculation.calculate_adaptive_ashrae(temp, mrt, 20, correction)
    # tmp_cmf_80_low, tmp_cmf_80_up, tmp_cmf_90_low, tmp_cmf_90_up = pm.adaptive_ashrae(temp, mrt, 20.0, correction)
    # result_text = (
    #     # f"The comfortable temperature (tmp_cmf) is: {tmp_cmf:.2f}°C.\n"
    #     f"The 80% acceptability limits = Operative temperature: {tmp_cmf_80_low:.2f} to {tmp_cmf_80_up:.2f}°C.\n"
    #     f"The 90% acceptability limits = Operative temperature: {tmp_cmf_90_low:.2f} to {tmp_cmf_90_up:.2f}°C.\n"
    # )
    # return result_text
    res = pm.adaptive_ashrae(temp, mrt, 20.0, correction)
    for key, value in res.items():
        if isinstance(value, np.ndarray):
            res[key] = value.tolist()

    res_str = json.dumps(res, indent=2, ensure_ascii=False)
    print(res_str)
    return html.Pre(res_str)

    




if __name__ == "__main__":
    app.run_server(
        debug=Config.DEBUG.value,
        host="127.0.0.1",
        port=os.environ.get("PORT_APP", 9090),
        processes=1,
        threaded=True,

    )

