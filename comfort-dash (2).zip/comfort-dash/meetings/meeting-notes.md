# Meeting Notes

## Meeting ##, 22-08-2024
Attendees: XX, YY, ZZ

Agenda:
- Working on branches, pull requests and merging


## Meeting ##, DD-MM-YYYY
Attendees: XX, YY, ZZ

Agenda:

<br>

### To-Do Items
- [ ] Item 1
- [ ] Item 2
- [ ] Item 3

<br>

### Updates
#### Admin
- Item a

#### Front-End
- Item b

#### Data & Visuals
- Item c

#### Back-End
- Item d

<br>

### Notes / Decisions
- Item 1
- Item 2
- Item 3

